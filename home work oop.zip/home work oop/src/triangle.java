public class triangle {

        int firstSide;
        int secondSide;
        int thirdSide;


        public int area(){
            return (firstSide*secondSide)/2;
        }
    }

